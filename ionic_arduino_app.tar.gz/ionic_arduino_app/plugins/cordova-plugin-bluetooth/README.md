# Cordova BLE Plugin

https://github.com/evothings/cordova-ble

## Installation

Install using the Apache Cordova command line:

    cordova plugin add cordova-plugin-bluetooth

