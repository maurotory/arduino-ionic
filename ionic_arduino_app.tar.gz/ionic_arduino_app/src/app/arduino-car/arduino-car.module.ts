import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ArduinoCarPageRoutingModule } from './arduino-car-routing.module';

import { ArduinoCarPage } from './arduino-car.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ArduinoCarPageRoutingModule
  ],
  declarations: [ArduinoCarPage]
})
export class ArduinoCarPageModule {}
