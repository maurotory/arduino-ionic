import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-arduino-car',
  templateUrl: './arduino-car.page.html',
  styleUrls: ['./arduino-car.page.scss'],
})
export class ArduinoCarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
