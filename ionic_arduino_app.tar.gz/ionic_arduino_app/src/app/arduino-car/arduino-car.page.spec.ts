import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ArduinoCarPage } from './arduino-car.page';

describe('ArduinoCarPage', () => {
  let component: ArduinoCarPage;
  let fixture: ComponentFixture<ArduinoCarPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArduinoCarPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ArduinoCarPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
