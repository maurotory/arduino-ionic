import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ArduinoCarPage } from './arduino-car.page';

const routes: Routes = [
  {
    path: '',
    component: ArduinoCarPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ArduinoCarPageRoutingModule {}
