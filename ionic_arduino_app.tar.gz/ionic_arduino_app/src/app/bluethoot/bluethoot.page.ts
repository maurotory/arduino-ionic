import { BluetoothSerial} from '@ionic-native/bluetooth-serial/ngx';
import { Component, OnInit } from '@angular/core';
import { AlertController, ToastController } from '@ionic/angular';


@Component({
  selector: 'app-bluethoot',
  templateUrl: './bluethoot.page.html',
  styleUrls: ['./bluethoot.page.scss'],
})
export class BluethootPage implements OnInit {

  pairedList: pairedList;
  listToggle:boolean = false;
  pairedDeviceID: number = 0;
  dataSend: string = "";

  constructor(private alertCtrl: AlertController, private bluetoothSerial: BluetoothSerial, private toastCtrl: ToastController) 
  {this.checkBluetoothEnabled(); }
  

  ngOnInit() {
  }

  checkBluetoothEnabled(){
    this.bluetoothSerial.isEnabled().then(success => {
      this.listPairedDevices();
      
    }, error => {
      this.showError("Please Enable Bluetooth")
    });
  }

  listPairedDevices() {
    this.bluetoothSerial.list().then(success =>{
      this.pairedList = success;
      this.listToggle = true;
    }, error =>{
      this.showError("Please Enable Bluetooth")
      this.listToggle = false;
    });
  }
  selectDevice(){
    let connectedDevice = this.pairedList[this.pairedDeviceID];
    if(!connectedDevice.adress){
      this.showError('Select Paired Device to connect');
      return;
    }
    let adress = connectedDevice.address;
    let name = connectedDevice.name;

    this.connect(adress)
  }

  connect(adress){
    this.bluetoothSerial.connect(adress).subscribe(success =>{
      this.deviceConnected();
      this.showToast("Successfully Connected");
    }, error =>{
      this.showError("Error: Connecting to Device");
    });
  }

  deviceConnected(){
    this.bluetoothSerial.subscribe('\n').subscribe(success =>{
      this.handleData(success);
      this.showToast("Connected Successfully");
    }, error =>{
      this.showError(error)
    });

  }
  handleData(data){
    this.showToast(data);
  }

  sendData(){
    this.dataSend+='\n';
    this.showToast(this.dataSend);

    this.bluetoothSerial.write(this.dataSend).then(success =>{
      this.showToast(success);
    }, error =>{
      this.showError(error)
    });

  }

  async showError(error){
    let alert = await this.alertCtrl.create({
      header: 'Error',
      subHeader: error,
      buttons: ['Dismiss']
    });
    alert.present();
  }

  async showToast(msj){
    const toast = await this.toastCtrl.create({
      message: msj,
      duration: 1000
    });
    toast.present();
  }


}

interface pairedList {
  "class": number,
  "id": string,
  "adress": string,
  "name": string

}
