import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { BluethootPage } from './bluethoot.page';

describe('BluethootPage', () => {
  let component: BluethootPage;
  let fixture: ComponentFixture<BluethootPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BluethootPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(BluethootPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
