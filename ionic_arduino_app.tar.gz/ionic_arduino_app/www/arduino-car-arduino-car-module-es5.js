function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["arduino-car-arduino-car-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/arduino-car/arduino-car.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/arduino-car/arduino-car.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppArduinoCarArduinoCarPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>arduino-car</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/arduino-car/arduino-car-routing.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/arduino-car/arduino-car-routing.module.ts ***!
    \***********************************************************/

  /*! exports provided: ArduinoCarPageRoutingModule */

  /***/
  function srcAppArduinoCarArduinoCarRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ArduinoCarPageRoutingModule", function () {
      return ArduinoCarPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _arduino_car_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./arduino-car.page */
    "./src/app/arduino-car/arduino-car.page.ts");

    var routes = [{
      path: '',
      component: _arduino_car_page__WEBPACK_IMPORTED_MODULE_3__["ArduinoCarPage"]
    }];

    var ArduinoCarPageRoutingModule = function ArduinoCarPageRoutingModule() {
      _classCallCheck(this, ArduinoCarPageRoutingModule);
    };

    ArduinoCarPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ArduinoCarPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/arduino-car/arduino-car.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/arduino-car/arduino-car.module.ts ***!
    \***************************************************/

  /*! exports provided: ArduinoCarPageModule */

  /***/
  function srcAppArduinoCarArduinoCarModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ArduinoCarPageModule", function () {
      return ArduinoCarPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _arduino_car_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./arduino-car-routing.module */
    "./src/app/arduino-car/arduino-car-routing.module.ts");
    /* harmony import */


    var _arduino_car_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./arduino-car.page */
    "./src/app/arduino-car/arduino-car.page.ts");

    var ArduinoCarPageModule = function ArduinoCarPageModule() {
      _classCallCheck(this, ArduinoCarPageModule);
    };

    ArduinoCarPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _arduino_car_routing_module__WEBPACK_IMPORTED_MODULE_5__["ArduinoCarPageRoutingModule"]],
      declarations: [_arduino_car_page__WEBPACK_IMPORTED_MODULE_6__["ArduinoCarPage"]]
    })], ArduinoCarPageModule);
    /***/
  },

  /***/
  "./src/app/arduino-car/arduino-car.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/arduino-car/arduino-car.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppArduinoCarArduinoCarPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FyZHVpbm8tY2FyL2FyZHVpbm8tY2FyLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/arduino-car/arduino-car.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/arduino-car/arduino-car.page.ts ***!
    \*************************************************/

  /*! exports provided: ArduinoCarPage */

  /***/
  function srcAppArduinoCarArduinoCarPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ArduinoCarPage", function () {
      return ArduinoCarPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var ArduinoCarPage = /*#__PURE__*/function () {
      function ArduinoCarPage() {
        _classCallCheck(this, ArduinoCarPage);
      }

      _createClass(ArduinoCarPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return ArduinoCarPage;
    }();

    ArduinoCarPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-arduino-car',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./arduino-car.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/arduino-car/arduino-car.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./arduino-car.page.scss */
      "./src/app/arduino-car/arduino-car.page.scss"))["default"]]
    })], ArduinoCarPage);
    /***/
  }
}]);
//# sourceMappingURL=arduino-car-arduino-car-module-es5.js.map