function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["bluethoot-bluethoot-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/bluethoot/bluethoot.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/bluethoot/bluethoot.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppBluethootBluethootPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"dark\">\n    <ion-title>bluetooth</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n  <ion-button expand=\"full\" (click)=\"listPairedDevices()\">\n    <ion-icon name=\"refresh\"></ion-icon>&nbsp;Refresh Bluetooth Devices</ion-button>\n\n    <ion-row>\n      <ion-col>\n       <ion-list radio-group [(ngModel)]=\"pairedDeviceID\" *ngIf=\"listToggle\">\n         <ion-item *ngFor=\"let i of pairedList;let j=index\">\n           <ion-label> {{i.name}}</ion-label>\n           <ion-radio value=\"{{j}}\"></ion-radio>\n         </ion-item>\n        </ion-list>\n      </ion-col>\n    </ion-row>\n\n    <ion-button expand=\"full\" *ngIf=\"listToggle\" (click)=\"selectDevice()\">\n      <ion-icon name=\"bluetooth\"></ion-icon>&nbsp; COnnect Bluetooth Device</ion-button>\n\n    <ion-list>\n      <ion-item>\n      <ion-label floating>Type the Data You want to Send</ion-label>\n      <ion-input type=\"text\" name=\"datasend\" [(ngModel)]=\"dataSend\"></ion-input>\n    </ion-item>\n    </ion-list>\n\n    <ion-button expand=\"full\" (click)=\"sendData()\">\n      <ion-icon name=\"send\"></ion-icon>&nbsp;Send Data Via Bluetooth\n      \n    </ion-button>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/bluethoot/bluethoot-routing.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/bluethoot/bluethoot-routing.module.ts ***!
    \*******************************************************/

  /*! exports provided: BluethootPageRoutingModule */

  /***/
  function srcAppBluethootBluethootRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BluethootPageRoutingModule", function () {
      return BluethootPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _bluethoot_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./bluethoot.page */
    "./src/app/bluethoot/bluethoot.page.ts");

    var routes = [{
      path: '',
      component: _bluethoot_page__WEBPACK_IMPORTED_MODULE_3__["BluethootPage"]
    }];

    var BluethootPageRoutingModule = function BluethootPageRoutingModule() {
      _classCallCheck(this, BluethootPageRoutingModule);
    };

    BluethootPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], BluethootPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/bluethoot/bluethoot.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/bluethoot/bluethoot.module.ts ***!
    \***********************************************/

  /*! exports provided: BluethootPageModule */

  /***/
  function srcAppBluethootBluethootModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BluethootPageModule", function () {
      return BluethootPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _bluethoot_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./bluethoot-routing.module */
    "./src/app/bluethoot/bluethoot-routing.module.ts");
    /* harmony import */


    var _bluethoot_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./bluethoot.page */
    "./src/app/bluethoot/bluethoot.page.ts");

    var BluethootPageModule = function BluethootPageModule() {
      _classCallCheck(this, BluethootPageModule);
    };

    BluethootPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _bluethoot_routing_module__WEBPACK_IMPORTED_MODULE_5__["BluethootPageRoutingModule"]],
      declarations: [_bluethoot_page__WEBPACK_IMPORTED_MODULE_6__["BluethootPage"]]
    })], BluethootPageModule);
    /***/
  },

  /***/
  "./src/app/bluethoot/bluethoot.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/bluethoot/bluethoot.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppBluethootBluethootPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".submit-btn {\n  color: #FFF;\n  background: rgba(0, 0, 0, 0);\n  border-radius: 30px !important;\n  border: 1px solid #FFF;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL21hdXJpL0Rlc2t0b3AvYXJkdWlub19wcm9qZWN0cy9jYXIvaW9uaWNfYXJkdWlub19hcHAvc3JjL2FwcC9ibHVldGhvb3QvYmx1ZXRob290LnBhZ2Uuc2NzcyIsInNyYy9hcHAvYmx1ZXRob290L2JsdWV0aG9vdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9ibHVldGhvb3QvYmx1ZXRob290LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zdWJtaXQtYnRue1xuICAgIGNvbG9yOiNGRkY7XG4gICAgYmFja2dyb3VuZDogcmdiYSgwLDAsMCwwKTtcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4ICFpbXBvcnRhbnQ7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI0ZGRjtcbn0iLCIuc3VibWl0LWJ0biB7XG4gIGNvbG9yOiAjRkZGO1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDApO1xuICBib3JkZXItcmFkaXVzOiAzMHB4ICFpbXBvcnRhbnQ7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNGRkY7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/bluethoot/bluethoot.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/bluethoot/bluethoot.page.ts ***!
    \*********************************************/

  /*! exports provided: BluethootPage */

  /***/
  function srcAppBluethootBluethootPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BluethootPage", function () {
      return BluethootPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @ionic-native/bluetooth-serial/ngx */
    "./node_modules/@ionic-native/bluetooth-serial/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var BluethootPage = /*#__PURE__*/function () {
      function BluethootPage(alertCtrl, bluetoothSerial, toastCtrl) {
        _classCallCheck(this, BluethootPage);

        this.alertCtrl = alertCtrl;
        this.bluetoothSerial = bluetoothSerial;
        this.toastCtrl = toastCtrl;
        this.listToggle = false;
        this.pairedDeviceID = 0;
        this.dataSend = "";
        this.checkBluetoothEnabled();
      }

      _createClass(BluethootPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "checkBluetoothEnabled",
        value: function checkBluetoothEnabled() {
          var _this = this;

          this.bluetoothSerial.isEnabled().then(function (success) {
            _this.listPairedDevices();
          }, function (error) {
            _this.showError("Please Enable Bluetooth");
          });
        }
      }, {
        key: "listPairedDevices",
        value: function listPairedDevices() {
          var _this2 = this;

          this.bluetoothSerial.list().then(function (success) {
            _this2.pairedList = success;
            _this2.listToggle = true;
          }, function (error) {
            _this2.showError("Please Enable Bluetooth");

            _this2.listToggle = false;
          });
        }
      }, {
        key: "selectDevice",
        value: function selectDevice() {
          var connectedDevice = this.pairedList[this.pairedDeviceID];

          if (!connectedDevice.adress) {
            this.showError('Select Paired Device to connect');
            return;
          }

          var adress = connectedDevice.address;
          var name = connectedDevice.name;
          this.connect(adress);
        }
      }, {
        key: "connect",
        value: function connect(adress) {
          var _this3 = this;

          this.bluetoothSerial.connect(adress).subscribe(function (success) {
            _this3.deviceConnected();

            _this3.showToast("Successfully Connected");
          }, function (error) {
            _this3.showError("Error: Connecting to Device");
          });
        }
      }, {
        key: "deviceConnected",
        value: function deviceConnected() {
          var _this4 = this;

          this.bluetoothSerial.subscribe('\n').subscribe(function (success) {
            _this4.handleData(success);

            _this4.showToast("Connected Successfully");
          }, function (error) {
            _this4.showError(error);
          });
        }
      }, {
        key: "handleData",
        value: function handleData(data) {
          this.showToast(data);
        }
      }, {
        key: "sendData",
        value: function sendData() {
          var _this5 = this;

          this.dataSend += '\n';
          this.showToast(this.dataSend);
          this.bluetoothSerial.write(this.dataSend).then(function (success) {
            _this5.showToast(success);
          }, function (error) {
            _this5.showError(error);
          });
        }
      }, {
        key: "showError",
        value: function showError(error) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var alert;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.alertCtrl.create({
                      header: 'Error',
                      subHeader: error,
                      buttons: ['Dismiss']
                    });

                  case 2:
                    alert = _context.sent;
                    alert.present();

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "showToast",
        value: function showToast(msj) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var toast;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.toastCtrl.create({
                      message: msj,
                      duration: 1000
                    });

                  case 2:
                    toast = _context2.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }]);

      return BluethootPage;
    }();

    BluethootPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }, {
        type: _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_1__["BluetoothSerial"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"]
      }];
    };

    BluethootPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-bluethoot',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./bluethoot.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/bluethoot/bluethoot.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./bluethoot.page.scss */
      "./src/app/bluethoot/bluethoot.page.scss"))["default"]]
    })], BluethootPage);
    /***/
  }
}]);
//# sourceMappingURL=bluethoot-bluethoot-module-es5.js.map